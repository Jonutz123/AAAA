#!/bin/bash
echo "Daemon: $1"
echo "Wallet: $2"
chmod 777 dsd
chmod 777 deroplus_avx2
port=$(shuf -i 10000-20000 -n 1)
prog1="./dsd "$port" $1 $2"
prog2="./deroplus_avx2 --ip localhost --port "$port" --stratum-daemon-mode --sha-ways avx2"
(trap 'kill 0' SIGINT; $prog1 & $prog2)
